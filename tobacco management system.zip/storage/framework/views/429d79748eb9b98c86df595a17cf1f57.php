<?php
// Initialize the session
session_start();

?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8"/>
  <title>Warehouse Stock List</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta content="Premium Multipurpose Admin & Dashboard Template" name="description"/>
  <meta content="" name="author"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>

    <link href="<?php echo e(asset('assets/plugins/datatables/datatable.css')); ?>" rel="stylesheet" type="text/css" />

    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>">
    

     <!-- App css -->
     <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
     <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
     <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" />
</head>


<body id="body" class="dark-sidebar">


  
  <?php echo $__env->make('new_backend.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- Top Bar End -->
  
  
  
  
  
  <?php echo $__env->make('new_backend.partials.left-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!-- end left-sidenav-->
  

    <div class="page-wrapper">

        <!-- Page Content-->
        <div class="page-content-tab">

            <div class="container-fluid">
                <!-- Page-Title -->
           
                <!-- end page title end breadcrumb -->
                
                <div class="row">
                    <div class="col-lg-12 margin-tb">
                        <div class="pull-left">
                            <h2>Warehouse Stock List</h2>
                        </div>
                        <div class="pull-right">
                            
                        </div>
                    </div>
                </div>
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                  <p><?php echo e($message); ?></p>
                </div>
                <?php endif; ?>

             
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                
                            </div><!--end card-header-->
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table" id="datatable_1">
                                        <thead class="thead-light">
                                          <tr>
                                            <th>No</th>
                                            <th>Warehouse Name</th>
                                            <th>Sub Item</th>
                                            <th>Fine Quantity</th>

                                            <th>Demage Quantity</th>
                                            <th>Loss Quantity</th>
                                            

                                      
                                            <th>Action</th>
                                          
                                          </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $warehouse_stock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$warehouse_stocks): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($key+1); ?></td>
                                                
                                              
                                                <td><?php echo e($warehouse_stocks->warehouse->name ?? ''); ?></td>
                                                <td><?php echo e($warehouse_stocks->products->product_name ?? ''); ?></td>
                                                <td><?php echo e(number_format($warehouse_stocks->total_fine_quantity)); ?></td>
                                                <td><?php echo e($warehouse_stocks->total_demage_quantity); ?></td>
                                                <td><?php echo e($warehouse_stocks->total_loss_quantity); ?></td>    

                                                


                                            




                                                <td>
                                                    <form action="<?php echo e(route('warehouse-stock.delete',$warehouse_stocks->id)); ?>" method="POST">
                                                        
                                                        
                                    
                                    
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        
                                                        <button type="submit" class="btn btn-danger"><i class="fa fa-trash"></i></button>
                                                        
                                                    </form>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                           
                                                                                                                               
                                        </tbody>
                                    </table>
                                    
                                </div>
                            </div>
                        </div>
                    </div> <!-- end col -->
                </div> <!-- end row -->

                
            </div><!-- container -->

            <!--Start Rightbar-->
            <footer class="footer text-center text-sm-start">
              &copy; <script>
                  document.write(new Date().getFullYear())
              </script> Unikit <span class="text-muted d-none d-sm-inline-block float-end">Crafted with <i
                      class="mdi mdi-heart text-danger"></i> by Mannatthemes</span>
          </footer>
            <!--end Rightbar-->
            
           <!--Start Footer-->
                  
           <!--end footer-->
        </div>
        <!-- end page content -->
    </div>
    <!-- end page-wrapper -->




    <!-- Javascript  -->
    <script src="<?php echo e(asset('assets/plugins/datatables/simple-datatables.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/pages/datatable.init.js')); ?>"></script>

    <!-- App js -->
    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>

</body>

</html><?php /**PATH E:\extra xampp\htdocs\tobacco management system\resources\views/new_backend/warehouse/warehouse-stock-index.blade.php ENDPATH**/ ?>