<?php
// Initialize the session
session_start();

?>
<!DOCTYPE html>
<html lang="en">
    <head>

  

        
        <meta charset="utf-8"/>
        <title>Add Product</title>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta content="Premium Multipurpose Admin & Dashboard Template" name="description"/>
        <meta content="" name="author"/>
        <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
         
    
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>">
        
    
         <!-- App css -->
         <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
         <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
         <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" />
    
    </head>

<body id="body" class="dark-sidebar">






<!-- Top Bar Start -->


<?php echo $__env->make('new_backend.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Top Bar End -->





<?php echo $__env->make('new_backend.partials.left-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- end left-sidenav-->





<div class="page-wrapper">

    <!-- Page Content-->
    <div class="page-content-tab">

        <div class="container-fluid">


            <div class="row">
                <div class="col-lg-12 margin-tb">
                    <div class="pull-left">
                        <h2>Add New Products</h2>
                    </div>
                    <div class="pull-right">
                        
                    </div>
                </div>
            </div>
           
            <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <strong>Whoops!</strong> There were some problems with your input.<br><br>
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
            <div class="row ">
                <div class="col-md-12 col-lg-12">

                    
                    


                    <form action="<?php echo e(route('products.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                
                
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <strong>Item:</strong>
                                    <select required name="category_id" class="form-control">
                                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($categories->id); ?>"><?php echo e($categories->category_name); ?></option>
                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                          <div class="col-md-6">
                              <div class="form-group">
                                  <strong>Sub Item:</strong>
                                  <input type="text" name="product_name" required class="form-control" placeholder="Sub Item">
                              </div>
                          </div>
                         
                          
                          
                          
                         
                          
                          <div class="col-md-12 text-center mt-3">
                              <button type="submit" class="btn btn-primary">Submit</button>
                          </div>
                      </div>
                
                
                    </form>
                    
                   
                </div> <!--end col-->
                
            </div><!--end row-->

           
        </div>
        <!-- container -->

        <!--Start Rightbar-->
     <!--Start Rightbar/offcanvas-->

<!--end Rightbar/offcanvas-->
        <!--end Rightbar-->

        <!--Start Footer-->
       <!-- Footer Start -->

       <footer class="footer text-center text-sm-start">
        &copy; <script>
            document.write(new Date().getFullYear())
        </script> <span class="text-muted d-none d-sm-inline-block float-end">Develop By by MindGigs </span>
    </footer>
<!-- end Footer -->


        <!--end footer-->
    </div>
    <!-- end page content -->
</div>
<!-- end page-wrapper -->

<!-- Javascript  -->

<script src="<?php echo e(asset('assets/plugins/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/pages/analytics-index.init.js')); ?>"></script>


<!-- App js -->
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>

</body>
<!--end body-->
</html><?php /**PATH E:\extra xampp\htdocs\tobacco management system\resources\views/new_backend/products/create.blade.php ENDPATH**/ ?>