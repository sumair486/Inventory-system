<div class="topbar">            
    <!-- Navbar -->
    <nav class="navbar-custom" id="navbar-custom">    
        <ul class="list-unstyled topbar-nav float-end mb-0">
            
            
            

            

            <li class="dropdown">
                <a class="nav-link dropdown-toggle nav-user" data-bs-toggle="dropdown" href="#" role="button"
                    aria-haspopup="false" aria-expanded="false">
                    <div class="d-flex align-items-center">
                        <img src="<?php echo e(asset('assets/images/users/logo_1.jpeg')); ?>" alt="profile-user" class="rounded-circle me-2 thumb-sm" />
                        <div>
                            
                            <span class="d-none d-md-block fw-semibold font-12"><?php echo e(Auth::user()->name); ?><i
                                    class="mdi mdi-chevron-down"></i></span>
                        </div>
                    </div>
                </a>
                <div class="dropdown-menu dropdown-menu-end">
                    
                    
                    
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                    <a class="dropdown-item" href="#" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="ti ti-power font-16 me-1 align-text-bottom"></i> Logout</a>
                </div>
                
            </li><!--end topbar-profile-->
            <li class="notification-list">
                <a class="nav-link arrow-none nav-icon offcanvas-btn" href="#" data-bs-toggle="offcanvas" data-bs-target="#Appearance" role="button" aria-controls="Rightbar">
                    <i class="ti ti-settings ti-spin"></i>
                </a>
            </li>   
        </ul><!--end topbar-nav-->

        <ul style="position:fixed" class="list-unstyled topbar-nav mb-0">                        
            
            <li class="hide-phone app-search">
                <form role="search" action="#" method="get">
                    <input type="search" name="search" class="form-control top-search mb-0" placeholder="Type text...">
                    <button type="submit"><i class="ti ti-search"></i></button>
                </form>
            </li>                       
        </ul>
    </nav>
    <!-- end navbar-->
</div><?php /**PATH E:\extra xampp\htdocs\tobacco management system\resources\views/new_backend/partials/navbar.blade.php ENDPATH**/ ?>