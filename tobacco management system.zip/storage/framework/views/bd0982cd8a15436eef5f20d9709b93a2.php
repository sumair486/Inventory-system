<div class="left-sidebar">
    <!-- LOGO -->
    <div class="brand">
        <a href="index.php" class="logo">
            <span>
                
            </span>
            <span>
                
                <img src="<?php echo e(asset('assets/images/logo-dark.png')); ?>" alt="logo-large" class="logo-lg logo-dark">
            </span>
        </a>
    </div>
    
    <div class="sidebar-user-pro media border-end">                    

        <div class="position-relative mx-auto">
            <img src="<?php echo e(asset('assets/images/users/logo_1.jpeg')); ?>" alt="user" class="rounded-circle thumb-md">
            <span class="online-icon position-absolute end-0"><i class="mdi mdi-record text-success"></i></span>
        </div>
        <div class="media-body ms-2 user-detail align-self-center">
            <h5 class="font-14 m-0 fw-bold"></h5>  
            <p class="opacity-50 mb-0">gulbahar general trading  Ltd</p>          
        </div>                    
    </div>
    <div class="border-end">
        <ul class="nav nav-tabs menu-tab nav-justified" role="tablist">
            
            
        </ul>
    </div>
    <!-- Tab panes -->
    
    <!--end logo-->
    <div class="menu-content h-100" data-simplebar>
        <div class="menu-body navbar-vertical">
            <div class="collapse navbar-collapse tab-content" id="sidebarCollapse">
                <!-- Navigation -->
                <ul class="navbar-nav tab-pane active" id="Main" role="tabpanel">
                    
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('dashboard')); ?>" 
                           >
                            <i class="ti ti-stack menu-icon"></i>
                            <span>Dashboard</span>
                        </a>
                        
                    </li><!--end nav-item-->


                 
                   

               


                    


                    <li class="nav-item">
                        <a class="nav-link" href="#border_transaction" data-bs-toggle="collapse" role="button"
                            aria-expanded="false" aria-controls="border_transaction">
                            <i class="ti ti-stack menu-icon"></i>
                            <span>Border Transaction</span>
                        </a>
                        <div class="collapse " id="border_transaction">
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('border.transaction')); ?>">Add Border Transaction</a>
                                </li><!--end nav-item-->
                                <li class="nav-item">
                                    <a href="<?php echo e(route('border.transaction.show')); ?>" class="nav-link ">Border Transaction List</a>
                                </li><!--end nav-item-->
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('border.detail.show')); ?>">Border Detail List</a>
                                </li><!--end nav-item-->
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('border.stock.show')); ?>">Border Stock List</a>
                                </li><!--end nav-item-->
                               
                               
                            </ul><!--end nav-->
                        </div><!--end sidebarAnalytics-->
                    </li><!--end nav-item-->

                    <li class="nav-item">
                        <a class="nav-link" href="#transfer" data-bs-toggle="collapse" role="button"
                            aria-expanded="false" aria-controls="transfer">
                            <i class="ti ti-stack menu-icon"></i>
                            <span>Transfer</span>
                        </a>
                        <div class="collapse " id="transfer">
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('transfer.create')); ?>">Add Transfer</a>
                                </li><!--end nav-item-->
                                <li class="nav-item">
                                    <a href="<?php echo e(route('transfer.show')); ?>" class="nav-link ">Transfer List</a>
                                </li><!--end nav-item-->
                               
                            </ul><!--end nav-->
                        </div><!--end sidebarAnalytics-->
                    </li><!--end nav-item-->

                    <li class="nav-item">
                        <a class="nav-link" href="#warehouse" data-bs-toggle="collapse" role="button"
                            aria-expanded="false" aria-controls="warehouse">
                            <i class="ti ti-stack menu-icon"></i>
                            <span>Warehouse</span>
                        </a>
                        <div class="collapse " id="warehouse">
                            <ul class="nav flex-column">
                               
                                <li class="nav-item">
                                    <a href="<?php echo e(route('warehouse-stock.show')); ?>" class="nav-link ">Warehouse Stock List</a>
                                </li><!--end nav-item-->
                               
                            </ul><!--end nav-->
                        </div><!--end sidebarAnalytics-->
                    </li><!--end nav-item-->

                    <li class="nav-item">
                        <a class="nav-link" href="#sale" data-bs-toggle="collapse" role="button"
                            aria-expanded="false" aria-controls="sale">
                            <i class="ti ti-stack menu-icon"></i>
                            <span>Sale</span>
                        </a>
                        <div class="collapse " id="sale">
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('sale.create')); ?>">Add Sale</a>
                                </li><!--end nav-item-->
                                <li class="nav-item">
                                    <a href="<?php echo e(route('sale.show')); ?>" class="nav-link ">Sale List</a>
                                </li><!--end nav-item-->
                               
                            </ul><!--end nav-->
                        </div><!--end sidebarAnalytics-->
                    </li><!--end nav-item-->

                    
                    

            
                    <li class="nav-item">
                        <a class="nav-link" href="#product" data-bs-toggle="collapse" role="button"
                            aria-expanded="false" aria-controls="product">
                            <i class="ti ti-stack menu-icon"></i>
                            <span>Sub Item</span>
                        </a>
                        <div class="collapse " id="product">
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('products.create')); ?>">Add Sub Item</a>
                                </li><!--end nav-item-->
                                <li class="nav-item">
                                    <a href="<?php echo e(route('products.index')); ?>" class="nav-link ">Sub Item List</a>
                                </li><!--end nav-item-->
                               
                            </ul><!--end nav-->
                        </div><!--end sidebarAnalytics-->
                    </li><!--end nav-item-->


                   

                    <li class="nav-item">
                        <a class="nav-link" href="#agent" data-bs-toggle="collapse" role="button"
                            aria-expanded="false" aria-controls="agent">
                            <i class="ti ti-stack menu-icon"></i>
                            <span>Delivery</span>
                        </a>
                        <div class="collapse " id="agent">
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('commission.create')); ?>">Add Delivery</a>
                                </li><!--end nav-item-->
                                <li class="nav-item">
                                    <a href="<?php echo e(route('commission.show')); ?>" class="nav-link ">Delivery  List</a>
                                </li><!--end nav-item-->
                                
                                
                               
                            </ul><!--end nav-->
                        </div><!--end sidebarAnalytics-->
                    </li><!--end nav-item-->
                   
                    <li class="nav-item">
                        <a class="nav-link" href="#setting" data-bs-toggle="collapse" role="button"
                            aria-expanded="false" aria-controls="setting">
                            <i class="ti ti-stack menu-icon"></i>
                            <span>Setting</span>
                        </a>
                        <div class="collapse " id="setting">
                            <ul class="nav flex-column">
                                
                                <li class="nav-item">
                                    <a href="<?php echo e(route('category.show')); ?>" class="nav-link ">Item</a>
                                </li><!--end nav-item-->
                                
                                
                                <li class="nav-item">
                                    <a href="<?php echo e(route('border.warehouse.show')); ?>" class="nav-link ">Border Warehouse</a>
                                </li>
                                
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('warehouse.create')); ?>">Add Warehouse</a>
                                </li><!--end nav-item-->
                                <li class="nav-item">
                                    <a href="<?php echo e(route('warehouse.show')); ?>" class="nav-link ">Warehouse List</a>
                                </li><!--end nav-item-->
                               
                            </ul><!--end nav-->
                        </div><!--end sidebarAnalytics-->
                    </li><!--end nav-item-->


                 
                    <li class="nav-item">
                        <a class="nav-link" href="#reports" data-bs-toggle="collapse" role="button"
                            aria-expanded="false" aria-controls="reports">
                            <i class="ti ti-stack menu-icon"></i>
                            <span>Reports</span>
                        </a>
                        <div class="collapse " id="reports">
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    
                                </li><!--end nav-item-->
                                <li class="nav-item">
                                    <a href="<?php echo e(route('report.border.stock')); ?>" class="nav-link ">Border Stock Report</a>
                                </li><!--end nav-item-->
                                
                                <li class="nav-item">
                                    <a href="<?php echo e(route('report.transfer')); ?>" class="nav-link ">Transfer Report</a>
                                </li><!--end nav-item-->  <li class="nav-item">
                                    <a href="<?php echo e(route('report.stock')); ?>" class="nav-link ">Warehouse Stock Report</a>
                                </li><!--end nav-item-->
                            </li><!--end nav-item-->  <li class="nav-item">
                                <a href="<?php echo e(route('report.sale')); ?>" class="nav-link ">Sale Report</a>
                            </li><!--end nav-item-->
                        </li><!--end nav-item-->  <li class="nav-item">
                            <a href="<?php echo e(route('border.combine.report')); ?>" class="nav-link ">All Stocks Report</a>
                        </li><!--end nav-item-->
                        
                               
                            </ul><!--end nav-->
                        </div><!--end sidebarAnalytics-->
                    </li><!--end nav-item-->

                                 
             

                    <li class="nav-item">
                        <a class="nav-link" href="#sidebarAnalytics" data-bs-toggle="collapse" role="button"
                            aria-expanded="false" aria-controls="sidebarAnalytics">
                            <i class="ti ti-stack menu-icon"></i>
                            <span>User Control</span>
                        </a>
                        <div class="collapse " id="sidebarAnalytics">
                            <ul class="nav flex-column">
                                <li class="nav-item">
                                    <a class="nav-link" href="<?php echo e(route('users.index')); ?>">User Management</a>
                                </li><!--end nav-item-->
                                <li class="nav-item">
                                    <a href="<?php echo e(route('roles.index')); ?>" class="nav-link ">Role Management</a>
                                </li><!--end nav-item-->
                               
                            </ul><!--end nav-->
                        </div><!--end sidebarAnalytics-->
                    </li><!--end nav-item-->


                    

                    

                    

                    

                    

                    
                    
                    

                    

                    

                    

                    

                    

                    

                    
                    
                    
                    
                </ul>
                <ul class="navbar-nav tab-pane" id="Extra" role="tabpanel">
                    <li>
                        <div class="update-msg text-center position-relative">
                            <button type="button" class="btn-close position-absolute end-0 me-2" aria-label="Close"></button>
                            <img src="<?php echo e(asset('assets/images/speaker-light.png')); ?>" alt="" class="" height="110">
                            <h5 class="mt-0">Mannat Themes</h5>
                            <p class="mb-3">We Design and Develop Clean and High Quality Web Applications</p>
                            <a href="javascript: void(0);" class="btn btn-outline-warning btn-sm">Upgrade your plan</a>
                        </div>
                    </li>
                </ul><!--end navbar-nav--->
            </div><!--end sidebarCollapse-->
        </div>
    </div>    
</div><?php /**PATH E:\extra xampp\htdocs\tobacco management system\resources\views/new_backend/partials/left-sidebar.blade.php ENDPATH**/ ?>