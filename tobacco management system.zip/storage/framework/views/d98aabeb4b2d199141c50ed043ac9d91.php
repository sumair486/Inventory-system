<?php
// Initialize the session
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>

  

    
    <meta charset="utf-8"/>
    <title>Tobacco Management System</title>
    
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta content="Premium Multipurpose Admin & Dashboard Template" name="description"/>
    <meta content="" name="author"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
     

    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>">
    
    
    
     <!-- App css -->
     <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
     <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
     <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" />

</head>

<body id="body" class="dark-sidebar">






<!-- Top Bar Start -->


<?php echo $__env->make('new_backend.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Top Bar End -->





<?php echo $__env->make('new_backend.partials.left-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- end left-sidenav-->





<div class="page-wrapper">

    <!-- Page Content-->
    <div class="page-content-tab">

        <div class="container-fluid">


            <div class="row">
               
                    
                </div>
                <div class="col-lg-12">
                    <div class="row justify-content-center">
                        <div class="col-lg-3">
                            <div class="card overflow-hidden">
                                <div class="card-body">
                                    <div class="row d-flex">
                                        <div class="col-3">
                                            <i class="ti ti-users font-36 align-self-center text-dark"></i>
                                        </div><!--end col-->
                                        <div class="col-12 ms-auto align-self-center">
                                            
                                        </div><!--end col-->
                                        <div class="col-12 ms-auto align-self-center">
                                            <a href="<?php echo e(route('getborder')); ?>">
                                            <h2 class="text-dark my-0 font-18 fw-bold">Border Warehouses</h2>
                                        </a>
                                            <h3 class="text-muted mb-0 fw-semibold"><?php echo e($border_warehouse_count); ?></h3>
                                        </div><!--end col-->
                                    </div><!--end row-->
                                </div><!--end card-body-->
                            </div><!--end card-->
                        </div> <!--end col-->

                        
                        <div class="col-lg-3">
                            <div class="card overflow-hidden">
                                <div class="card-body">
                                    <div class="row d-flex">
                                        <div class="col-3">
                                            <i class="ti ti-activity font-36 align-self-center text-dark"></i>
                                        </div><!--end col-->
                                        <div class="col-12 ms-auto align-self-center">
                                            
                                        </div><!--end col-->
                                        <div class="col-12 ms-auto align-self-center">
                                            <a href="<?php echo e(route('getwarehouse')); ?>">
                                            <h2 class="text-dark my-0 font-18 fw-bold">Peshawar Warehouse</h2>
                                        </a>
                                            <h3 class="text-muted mb-0 fw-semibold"><?php echo e($stock_count); ?></h3>
                                        </div><!--end col-->
                                    </div><!--end row-->
                                </div><!--end card-body-->
                            </div><!--end card-->
                        </div> <!--end col-->

                        <div class="col-lg-3">
                            <div class="card overflow-hidden">
                                <div class="card-body">
                                    <div class="row d-flex">
                                        <div class="col-3">
                                            <i class="ti ti-clock font-36 align-self-center text-dark"></i>
                                        </div><!--end col-->
                                        <div class="col-auto ms-auto align-self-center">
                                            <span class="badge badge-soft-success px-2 py-1 font-11">Active</span>
                                        </div><!--end col-->
                                        <div class="col-12 ms-auto align-self-center">
                                            
                                        </div><!--end col-->
                                        <div class="col-12 ms-auto align-self-center">
                                            <h2 class="text-dark my-0 font-18 fw-bold">Total Sub Item</h2>
                                            <h3 class="text-muted mb-0 fw-semibold"><?php echo e($count_product); ?></h3>
                                        </div><!--end col-->
                                    </div><!--end row-->
                                </div><!--end card-body-->
                            </div><!--end card-->
                        </div> <!--end col-->


                        

                       

                        <div class="col-lg-3">
                            <div class="card overflow-hidden">
                                <div class="card-body">
                                    <div class="row d-flex">
                                        <div class="col-3">
                                            <i class="ti ti-confetti font-36 align-self-center text-dark"></i>
                                        </div><!--end col-->
                                        <div class="col-auto ms-auto align-self-center">
                                            
                                        </div><!--end col-->
                                        <div class="col-12 ms-auto align-self-center">
                                            
                                        </div><!--end col-->
                                        <div class="col-12 ms-auto align-self-center">
                                            <h2 class="text-dark my-0 font-18 fw-bold">Total Sales</h2>
                                            <h3 class="text-muted mb-0 fw-semibold"><?php echo e($sale); ?></h3>
                                        </div><!--end col-->
                                    </div><!--end row-->
                                </div><!--end card-body-->
                            </div><!--end card-->
                        </div> <!--end col-->
                    </div><!--end row-->

                  

                </div><!--end col-->
            </div><!--end row-->

           
        </div><!-- container -->

        <!--Start Rightbar-->
     <!--Start Rightbar/offcanvas-->

<!--end Rightbar/offcanvas-->
        <!--end Rightbar-->

        <!--Start Footer-->
       <!-- Footer Start -->

       <footer class="footer text-center text-sm-start">
        &copy; <script>
            document.write(new Date().getFullYear())
        </script> <span class="text-muted d-none d-sm-inline-block float-end">Develop By by MindGigs </span>
    </footer>

<!-- end Footer -->


        <!--end footer-->
    </div>
    <!-- end page content -->
</div>
<!-- end page-wrapper -->

<!-- Javascript  -->

<script src="<?php echo e(asset('assets/plugins/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/pages/analytics-index.init.js')); ?>"></script>


<!-- App js -->
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>

</body>
<!--end body-->
</html><?php /**PATH E:\extra xampp\htdocs\tobacco management system\resources\views/new_backend/index.blade.php ENDPATH**/ ?>