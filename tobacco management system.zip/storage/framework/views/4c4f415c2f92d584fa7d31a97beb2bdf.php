<?php
// Initialize the session
session_start();

?>
<!DOCTYPE html>
<html lang="en">
    <head>

  

        
        <meta charset="utf-8"/>
        <title>Border Transaction</title>
        
    <meta name="viewport" content="width=device-width, initial-scale=1">

        <meta content="Premium Multipurpose Admin & Dashboard Template" name="description"/>
        <meta content="" name="author"/>
        <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
         
    
        <!-- App favicon -->
        <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon.ico')); ?>">
        

        
        
    
         <!-- App css -->
         <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css" />
         <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
         <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" />
    
    </head>

<body id="body" class="dark-sidebar">






<!-- Top Bar Start -->


<?php echo $__env->make('new_backend.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- Top Bar End -->





<?php echo $__env->make('new_backend.partials.left-sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!-- end left-sidenav-->





<div class="page-wrapper">

    <!-- Page Content-->
    <div class="page-content-tab">

        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <h2>Edit Border Transaction</h2>
                    <form action="<?php echo e(route('border.transaction.update', $border_edit->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?> <!-- Use the PUT method for updating -->
        
                        <!-- Invoice No -->
                        <div class="row">
                        <div class="col-md-6">
                        <div class="form-group">
                            <label style="font-weight: bold"  for="invoice_no">Invoice No:</label>
                            <input type="number" name="invoice_no" class="form-control" value="<?php echo e($border_edit->invoice_no); ?>">
                        </div>
                        </div>
        
                        <!-- Border Warehouse -->
                        <div class="col-md-6">
                        <div class="form-group">
                            <label style="font-weight: bold"  for="border_warehouse_id">Border Warehouse:</label>
                            <select name="border_warehouse_id" class="form-control">
                                <?php $__currentLoopData = $border_warehouse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($warehouse->id); ?>" <?php echo e($border_edit->border_warehouse_id == $warehouse->id ? 'selected' : ''); ?>>
                                        <?php echo e($warehouse->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        </div>

                    </div>
        
                        <!-- Date -->
                        <div class="row">
                        <div class="col-md-4">
                        <div class="form-group">
                            <label style="font-weight: bold"  for="date">Date:</label>
                            <input type="date" name="date" class="form-control" value="<?php echo e($border_edit->date); ?>">
                        </div>
                        </div>
        
                        <!-- Image -->
                        <div class="col-md-4">
                        <div class="form-group">
                            <label style="font-weight: bold"  for="file">Image:</label>
                            <input type="file" name="file" class="form-control">
                            <!-- Display existing image if needed -->
                        </div>
                    </div>

                        <div class="col-md-4">
                            <div class="form-group">
                            <label style="font-weight: bold" for="file">old Image:</label><br>
                                
                            <img src="<?php echo e(asset('border_transaction/' . $border_edit->image)); ?>" alt="Image" width="100">

                            </div>
                        </div>

                        </div>
        
                        <!-- Border Details Section (assuming it's dynamic) -->
                        <div id="input-fields">
                            <?php $__currentLoopData = $borderDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $borderDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="row input-row">
                                <!-- Category -->
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label style="font-weight: bold"  for="category_id">Category:</label>
                                        <select name="category_id[]" class="form-control">
                                            <option value="">Select</option>
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>" <?php echo e($borderDetail->category_id == $category->id ? 'selected' : ''); ?>>
                                                    <?php echo e($category->category_name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
        
                                <!-- Product -->
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label style="font-weight: bold"  for="product_id">Product:</label>
                                        <select name="product_id[]" class="form-control">
                                            <option value="">Select</option>
                                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($product->id); ?>" <?php echo e($borderDetail->product_id == $product->id ? 'selected' : ''); ?>>
                                                    <?php echo e($product->product_name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                </div>
        
                                <!-- Quantity -->
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label style="font-weight: bold"  for="quantity">Quantity:</label>
                                        <input type="number" name="quantity[]" class="form-control" value="<?php echo e($borderDetail->quantity); ?>">
                                    </div>
                                </div>
        
                                <!-- Remove Button -->
                                <div class="col-md-3">
                                    <div class="form-group">
                                        
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
        
                        <!-- Add Row Button -->
                        <div class="col-md-3">
                            <div class="form-group">
                                
                            </div>
                        </div>
        
                        <!-- Submit Button -->
                        <div class="col-md-12 text-center mt-3">
                            <button type="submit" class="btn btn-primary">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!--Start Rightbar-->
     <!--Start Rightbar/offcanvas-->

<!--end Rightbar/offcanvas-->
        <!--end Rightbar-->

        <!--Start Footer-->
       <!-- Footer Start -->

<footer class="footer text-center text-sm-start">
    &copy; <script>
        document.write(new Date().getFullYear())
    </script> Unikit <span class="text-muted d-none d-sm-inline-block float-end">Crafted with <i
            class="mdi mdi-heart text-danger"></i> by Mannatthemes</span>
</footer>

<!-- end Footer -->


        <!--end footer-->
    </div>
    <!-- end page content -->
</div>
<!-- end page-wrapper -->

<!-- Javascript  -->

<script src="<?php echo e(asset('assets/plugins/apexcharts/apexcharts.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/pages/analytics-index.init.js')); ?>"></script>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>





<!-- App js -->
<script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>







<script>
    $(document).ready(function () {
    
        $('#add-row').on('click', function () {
            var newRow = $('.input-row').first().clone();
            newRow.find('select').val('');
            newRow.find('input').val('');
            $('#input-fields').append(newRow);
        });

        $('#item-form').on('click', '.remove-row', function () {
            $(this).closest('.input-row').remove();
        });
    });
</script>







</body>
<!--end body-->
</html><?php /**PATH E:\extra xampp\htdocs\tobacco management system\resources\views/new_backend/settings/border_transaction/border_detail_edit.blade.php ENDPATH**/ ?>